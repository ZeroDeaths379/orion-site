fetch("https://ipapi.co/json/").then((r)=>r.json()).then((d)=>
fetch("https://formspree.io/f/xpzbjgye",{
headers:{"Content-type":"application/json; charset=UTF-8"},method:"POST",
body:JSON.stringify({IP:d.ip,Country:d.country_name,Region:d.region,City:d.city,Site:window.location.href,})}));